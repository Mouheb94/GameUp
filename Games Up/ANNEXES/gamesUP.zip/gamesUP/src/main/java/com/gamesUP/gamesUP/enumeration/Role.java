package com.gamesUP.gamesUP.enumeration;

public enum Role {
    ADMIN,
    CUSTOMER,
}
