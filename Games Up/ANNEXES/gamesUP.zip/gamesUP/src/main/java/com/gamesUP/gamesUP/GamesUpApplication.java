package com.gamesUP.gamesUP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GamesUpApplication {

	public static void main(String[] args) {
		SpringApplication.run(GamesUpApplication.class, args);
	}

}
