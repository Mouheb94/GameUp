package com.gamesUP.gamesUP.repository;

public interface PurchaseLineRepository {
}
