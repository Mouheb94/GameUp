package com.gamesUP.gamesUP.entity;

public class PurchaseLine {
	
	private int id;
    private int utilisateurId;
    private int jeuId;
    private double prix;

}
