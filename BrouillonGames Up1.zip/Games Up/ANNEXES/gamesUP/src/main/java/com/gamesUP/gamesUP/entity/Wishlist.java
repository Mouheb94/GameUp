package com.gamesUP.gamesUP.entity;

public class Wishlist {

}
