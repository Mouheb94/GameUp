package com.gamesUP.gamesUP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GamesUpApplicationTests {

	@Test
	void contextLoads() {
	}

}
